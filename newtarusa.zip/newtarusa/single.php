<?php get_header(); ?>

<div class="container">
<div class="bg"></div>
<div class="wrapper wr-single">
<?php get_sidebar(); ?>
<section class="services" style="padding-top: 0">
<div class="breadcrumb">
<a href="<?php echo get_page_link(548); ?>">Главная</a> » 
<?php
if(function_exists('bcn_display'))
{
    bcn_display();
}
?>
</div>
<div class="post">
        <div class="services__title-wrapper">
            <h1 class="services__title single__title">
                 <?php the_title(); ?>
            <h1>
        </div>	

        <div class="podrobnosti">
        <span class="post-time">Опубликовано: <?php the_time( 'd.m.y') ?></span>
        </div>
    <?php the_content(); ?>
</div>
<?php setPostViews(get_the_ID()); ?>
</section>

</div>
</div>

<?php get_footer(); ?>