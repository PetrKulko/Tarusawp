<?php get_header(); ?>



<div class="container">

<div class="wrapper wr-zapisi">

<?php get_sidebar(); ?>

<section class="services not__found">

    <div class="not__found-content">

        <h1 class="services__title not__found-title">

            404

        </h1>

        <p class="not__found-text">Ошибка! <br> К сожалению, запрашиваемая Вами страница не найдена...</p>

        <div class="not__found-link--wrapper">

            <a class="not__found-link" href="<?php echo get_page_link(548); ?>">Главная страница</a>

        </div>

    </div>

    <div class="not__found-img--wrapper">

        <img class="not__found-img" src="<?php bloginfo( 'template_url' ); ?>/assets/img/img404.jpg" alt="bg">

    </div>

</section>



</div>

</div>



<?php get_footer(); ?>

