<?php get_header(); ?>

<div class="container">
<div class="bg"></div>
<div class="wrapper wr-zapisi">
<?php get_sidebar(); ?>
<section class="services"  style="padding-top: 0px">
<div class="breadcrumb">
<a href="<?php echo get_page_link(548); ?>">Главная</a> » 
<?php
if(function_exists('bcn_display'))
{
    bcn_display();
}
?>
</div>
<div class="post contacts__post" style="margin-top: 5px;">
        <div class="services__title-wrapper">
            <h1 class="services__title single__title">
                 <?php the_title(); ?>
            <h1>
        </div>	
        <div class="container">
            <div class="footer__items contact__items" style="padding-top:10px">

                <div class="footer__item" style="display: flex; flex-direction: column">
                    <p>Адрес:</p>
                    <p style="margin-top: 0px">Россия, Калужская область, г. Таруса, ул. Розы Люксембург, д. 18</p>
                    </div>
                <div class="footer__item">
                    <p class="footer__item-text">Email:</p>
                    <a class="footer__item-email" href="mailto:<?php the_field('footer__item-email', 2) ?>"><?php the_field('footer__item-email', 2) ?></a>
                </div>
                <div class="footer__item">
                    <p class="footer__item-text">Телефон:</p>
                    <a class="footer__item-phone" href="tel:<?php the_field('footer__item-phone', 2) ?>"><?php the_field('footer__item-phone', 2) ?></a>
                </div>
            </div>
        </div>
        <div class="contacts__content">
            <div class="contacts__info">
                <div class="contacts__info-item">

                </div>
                <div class="contacts__info-form">
                    <h2>Обратная связь</h2>

                    <?php echo do_shortcode( '[contact-form-7 id="624" title="Без названия"]' ); ?>
                </div>
            </div>
            <div class="contacts__map">
            <script type="text/javascript" charset="utf-8" async src="https://api-maps.yandex.ru/services/constructor/1.0/js/?um=constructor%3A8ff1e00b6e43f91b2efc8b013e2f68976916627156e9318638dfd3d5173a70de&amp;max-width=100%&amp;lang=ru_RU&amp;scroll=true"></script>
            </div>
        </div>
</div>

</div>

</section>
</div>
</div>

<?php get_footer(); ?>