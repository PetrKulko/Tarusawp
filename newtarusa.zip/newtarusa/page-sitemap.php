<?php get_header(); ?>

<div class="container">
<div class="bg"></div>
<div class="wrapper wr-zapisi">
<?php get_sidebar(); ?>
<section class="services services__sitemap" style="padding-top: 0">
<div class="breadcrumb">
<a href="<?php echo get_page_link(548); ?>">Главная</a> » 
<?php
if(function_exists('bcn_display'))
{
    bcn_display();
}
?>
</div>
<div class="post">
<?php get_template_part('/partials/sitemap'); ?>
</div>

</section>
</div>
</div>

<?php get_footer(); ?>





