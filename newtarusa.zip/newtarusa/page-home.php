<?php get_header(); ?>



    <div class="container">

        <div class="bg"></div>

        <div class="wrapper wr-main">

        <?php get_sidebar(); ?>
            <section class="services">

                <div class="container">

                    <div class="services__title-wrapper">

                        <h2 class="services__title home__title"><?php the_field('services__title', 2) ?></h2>

                    </div>

                    <?php get_search_form(); ?>

                    <div class="services__popup">

                        <a class="services__popup-link" id="write" href="#header"></a>

                            <!-- ВИДЖЕТ -->

                            <script src="https://pos.gosuslugi.ru/bin/script.min.js"></script> 
<style>
@charset "UTF-8";#js-show-iframe-wrapper{position:relative;display:flex;align-items:center;justify-content:center;width:100%;min-width:260px;max-width:100%;background:linear-gradient(138.4deg,#38bafe 26.49%,#2d73bc 79.45%);color:#fff; cursor: pointer;}#js-show-iframe-wrapper .pos-banner-fluid *{box-sizing:border-box}#js-show-iframe-wrapper .pos-banner-fluid .pos-banner-btn_2{display:block;width:195px;min-height:56px;font-size:18px;line-height:24px;cursor:pointer;background:#0d4cd3;color:#fff;border:none;border-radius:8px;outline:0}#js-show-iframe-wrapper .pos-banner-fluid .pos-banner-btn_2:hover{background:#1d5deb}#js-show-iframe-wrapper .pos-banner-fluid .pos-banner-btn_2:focus{background:#2a63ad}#js-show-iframe-wrapper .pos-banner-fluid .pos-banner-btn_2:active{background:#2a63ad}@-webkit-keyframes fadeInFromNone{0%{display:none;opacity:0}1%{display:block;opacity:0}100%{display:block;opacity:1}}@keyframes fadeInFromNone{0%{display:none;opacity:0}1%{display:block;opacity:0}100%{display:block;opacity:1}}@font-face{font-family:LatoWebLight;src:url(https://pos.gosuslugi.ru/bin/fonts/Lato/fonts/Lato-Light.woff2) format("woff2"),url(https://pos.gosuslugi.ru/bin/fonts/Lato/fonts/Lato-Light.woff) format("woff"),url(https://pos.gosuslugi.ru/bin/fonts/Lato/fonts/Lato-Light.ttf) format("truetype");font-style:normal;font-weight:400;text-rendering:optimizeLegibility}@font-face{font-family:LatoWeb;src:url(https://pos.gosuslugi.ru/bin/fonts/Lato/fonts/Lato-Regular.woff2) format("woff2"),url(https://pos.gosuslugi.ru/bin/fonts/Lato/fonts/Lato-Regular.woff) format("woff"),url(https://pos.gosuslugi.ru/bin/fonts/Lato/fonts/Lato-Regular.ttf) format("truetype");font-style:normal;font-weight:400;text-rendering:optimizeLegibility}@font-face{font-family:LatoWebBold;src:url(https://pos.gosuslugi.ru/bin/fonts/Lato/fonts/Lato-Bold.woff2) format("woff2"),url(https://pos.gosuslugi.ru/bin/fonts/Lato/fonts/Lato-Bold.woff) format("woff"),url(https://pos.gosuslugi.ru/bin/fonts/Lato/fonts/Lato-Bold.ttf) format("truetype");font-style:normal;font-weight:400;text-rendering:optimizeLegibility}
</style>
<style>
#js-show-iframe-wrapper .bf-2{position:relative;display:grid;grid-template-columns:var(--pos-banner-fluid-2__grid-template-columns);grid-template-rows:var(--pos-banner-fluid-2__grid-template-rows);width:100%;max-width:1060px;font-family:LatoWeb,sans-serif;box-sizing:border-box}#js-show-iframe-wrapper .bf-2__decor{grid-column:var(--pos-banner-fluid-2__decor-grid-column);grid-row:var(--pos-banner-fluid-2__decor-grid-row);padding:var(--pos-banner-fluid-2__decor-padding);background:var(--pos-banner-fluid-2__bg-url) var(--pos-banner-fluid-2__bg-position) no-repeat;background-size:var(--pos-banner-fluid-2__bg-size)}#js-show-iframe-wrapper .bf-2__logo-wrap{position:absolute;top:var(--pos-banner-fluid-2__logo-wrap-top);bottom:var(--pos-banner-fluid-2__logo-wrap-bottom);right:0;display:flex;flex-direction:column;align-items:flex-end;padding:var(--pos-banner-fluid-2__logo-wrap-padding);background:#2d73bc;border-radius:var(--pos-banner-fluid-2__logo-wrap-border-radius)}#js-show-iframe-wrapper .bf-2__logo{width:128px}#js-show-iframe-wrapper .bf-2__slogan{font-family:LatoWebBold,sans-serif;font-size:var(--pos-banner-fluid-2__slogan-font-size);line-height:var(--pos-banner-fluid-2__slogan-line-height)}#js-show-iframe-wrapper .bf-2__content{padding:var(--pos-banner-fluid-2__content-padding)}#js-show-iframe-wrapper .bf-2__description{display:flex;flex-direction:column;margin-bottom:24px}#js-show-iframe-wrapper .bf-2__text{margin-bottom:12px;font-size:24px;line-height:32px;font-family:LatoWebBold,sans-serif}#js-show-iframe-wrapper .bf-2__text_small{margin-bottom:0;font-size:16px;line-height:24px;font-family:LatoWeb,sans-serif}#js-show-iframe-wrapper .bf-2__btn-wrap{display:flex;align-items:center;justify-content:center}
</style>
<div id="js-show-iframe-wrapper">
  <div class="pos-banner-fluid bf-2">
    <div class="bf-2__decor">
      <div class="bf-2__logo-wrap">
        <img class="bf-2__logo" src="https://pos.gosuslugi.ru/bin/banner-fluid/gosuslugi-logo.svg" alt="Госуслуги">
        <div class="bf-2__slogan">Жалобы на всё</div>
      </div>
    </div>
    <div class="bf-2__content">
      <div class="bf-2__description">
          <span class="bf-2__text">
            Не убран мусор, яма на дороге, не горит фонарь?
<!--            Не убран мусор, яма на дороге, не горит фонарь?-->
          </span>
        <span class="pos-banner-fluid__text pos-banner-fluid__text_small">
            Столкнулись с проблемой&nbsp;— сообщите о ней!
<!--          Столкнулись с проблемой&nbsp;— сообщите о ней!-->
          </span>
      </div>
      <div class="bf-2__btn-wrap">
        <!-- pos-banner-btn_2 не удалять; другие классы не добавлять -->
        <button class="pos-banner-btn_2" type="button">Подать жалобу
        </button>
      </div>
    </div>
  </div>
</div>
<script>
"use strict";var root=document.documentElement,banner=document.getElementById("js-show-iframe-wrapper");function displayWindowSize(){var o=banner.offsetWidth;o<=405&&(root.style.setProperty("--pos-banner-fluid-2__grid-template-columns","100%"),root.style.setProperty("--pos-banner-fluid-2__grid-template-rows","310px auto"),root.style.setProperty("--pos-banner-fluid-2__decor-grid-column","initial"),root.style.setProperty("--pos-banner-fluid-2__decor-grid-row","initial"),root.style.setProperty("--pos-banner-fluid-2__decor-padding","30px 30px 0 30px"),root.style.setProperty("--pos-banner-fluid-2__content-padding","0 30px 30px 30px"),root.style.setProperty("--pos-banner-fluid-2__bg-url","url('https://pos.gosuslugi.ru/bin/banner-fluid/2/banner-fluid-bg-2-small.svg')"),root.style.setProperty("--pos-banner-fluid-2__bg-position","calc(10% + 64px) calc(100% - 20px)"),root.style.setProperty("--pos-banner-fluid-2__bg-size","cover"),root.style.setProperty("--pos-banner-fluid-2__slogan-font-size","20px"),root.style.setProperty("--pos-banner-fluid-2__slogan-line-height","32px"),root.style.setProperty("--pos-banner-fluid-2__logo-wrap-padding","20px 30px 30px 40px"),root.style.setProperty("--pos-banner-fluid-2__logo-wrap-top","0"),root.style.setProperty("--pos-banner-fluid-2__logo-wrap-bottom","initial"),root.style.setProperty("--pos-banner-fluid-2__logo-wrap-border-radius","0 0 0 80px")),o>405&&o<=500&&(root.style.setProperty("--pos-banner-fluid-2__grid-template-columns","100%"),root.style.setProperty("--pos-banner-fluid-2__grid-template-rows","310px auto"),root.style.setProperty("--pos-banner-fluid-2__decor-grid-column","initial"),root.style.setProperty("--pos-banner-fluid-2__decor-grid-row","initial"),root.style.setProperty("--pos-banner-fluid-2__decor-padding","30px 30px 0 30px"),root.style.setProperty("--pos-banner-fluid-2__content-padding","0 30px 30px 30px"),root.style.setProperty("--pos-banner-fluid-2__bg-url","url('https://pos.gosuslugi.ru/bin/banner-fluid/2/banner-fluid-bg-2-small.svg')"),root.style.setProperty("--pos-banner-fluid-2__bg-position","calc(10% + 64px) calc(100% - 20px)"),root.style.setProperty("--pos-banner-fluid-2__bg-size","cover"),root.style.setProperty("--pos-banner-fluid-2__slogan-font-size","24px"),root.style.setProperty("--pos-banner-fluid-2__slogan-line-height","32px"),root.style.setProperty("--pos-banner-fluid-2__logo-wrap-padding","30px 50px 30px 70px"),root.style.setProperty("--pos-banner-fluid-2__logo-wrap-top","0"),root.style.setProperty("--pos-banner-fluid-2__logo-wrap-bottom","initial"),root.style.setProperty("--pos-banner-fluid-2__logo-wrap-border-radius","0 0 0 80px")),o>500&&o<=585&&(root.style.setProperty("--pos-banner-fluid-2__grid-template-columns","min-content 1fr"),root.style.setProperty("--pos-banner-fluid-2__grid-template-rows","100%"),root.style.setProperty("--pos-banner-fluid-2__decor-grid-column","2"),root.style.setProperty("--pos-banner-fluid-2__decor-grid-row","1"),root.style.setProperty("--pos-banner-fluid-2__decor-padding","30px 30px 30px 0"),root.style.setProperty("--pos-banner-fluid-2__content-padding","30px"),root.style.setProperty("--pos-banner-fluid-2__bg-url","url('https://pos.gosuslugi.ru/bin/banner-fluid/2/banner-fluid-bg-2-small.svg')"),root.style.setProperty("--pos-banner-fluid-2__bg-position","0% calc(100% - 70px)"),root.style.setProperty("--pos-banner-fluid-2__bg-size","cover"),root.style.setProperty("--pos-banner-fluid-2__slogan-font-size","24px"),root.style.setProperty("--pos-banner-fluid-2__slogan-line-height","32px"),root.style.setProperty("--pos-banner-fluid-2__logo-wrap-padding","30px 30px 24px 40px"),root.style.setProperty("--pos-banner-fluid-2__logo-wrap-top","initial"),root.style.setProperty("--pos-banner-fluid-2__logo-wrap-bottom","0"),root.style.setProperty("--pos-banner-fluid-2__logo-wrap-border-radius","80px 0 0 0")),o>585&&o<=800&&(root.style.setProperty("--pos-banner-fluid-2__grid-template-columns","min-content 1fr"),root.style.setProperty("--pos-banner-fluid-2__grid-template-rows","100%"),root.style.setProperty("--pos-banner-fluid-2__decor-grid-column","2"),root.style.setProperty("--pos-banner-fluid-2__decor-grid-row","1"),root.style.setProperty("--pos-banner-fluid-2__decor-padding","30px 30px 30px 0"),root.style.setProperty("--pos-banner-fluid-2__content-padding","30px"),root.style.setProperty("--pos-banner-fluid-2__bg-url","url('https://pos.gosuslugi.ru/bin/banner-fluid/2/banner-fluid-bg-2-small.svg')"),root.style.setProperty("--pos-banner-fluid-2__bg-position","0% calc(100% - 6px)"),root.style.setProperty("--pos-banner-fluid-2__bg-size","cover"),root.style.setProperty("--pos-banner-fluid-2__slogan-font-size","24px"),root.style.setProperty("--pos-banner-fluid-2__slogan-line-height","32px"),root.style.setProperty("--pos-banner-fluid-2__logo-wrap-padding","30px 30px 24px 40px"),root.style.setProperty("--pos-banner-fluid-2__logo-wrap-top","initial"),root.style.setProperty("--pos-banner-fluid-2__logo-wrap-bottom","0"),root.style.setProperty("--pos-banner-fluid-2__logo-wrap-border-radius","80px 0 0 0")),o>800&&o<=1020&&(root.style.setProperty("--pos-banner-fluid-2__grid-template-columns","min-content 1fr"),root.style.setProperty("--pos-banner-fluid-2__grid-template-rows","100%"),root.style.setProperty("--pos-banner-fluid-2__decor-grid-column","2"),root.style.setProperty("--pos-banner-fluid-2__decor-grid-row","1"),root.style.setProperty("--pos-banner-fluid-2__decor-padding","30px 30px 30px 0"),root.style.setProperty("--pos-banner-fluid-2__content-padding","30px"),root.style.setProperty("--pos-banner-fluid-2__bg-url","url('https://pos.gosuslugi.ru/bin/banner-fluid/2/banner-fluid-bg-2.svg')"),root.style.setProperty("--pos-banner-fluid-2__bg-position","0% center"),root.style.setProperty("--pos-banner-fluid-2__bg-size","cover"),root.style.setProperty("--pos-banner-fluid-2__slogan-font-size","24px"),root.style.setProperty("--pos-banner-fluid-2__slogan-line-height","32px"),root.style.setProperty("--pos-banner-fluid-2__logo-wrap-padding","30px 30px 24px 40px"),root.style.setProperty("--pos-banner-fluid-2__logo-wrap-top","initial"),root.style.setProperty("--pos-banner-fluid-2__logo-wrap-bottom","0"),root.style.setProperty("--pos-banner-fluid-2__logo-wrap-border-radius","80px 0 0 0")),o>1020&&(root.style.setProperty("--pos-banner-fluid-2__grid-template-columns","min-content 1fr"),root.style.setProperty("--pos-banner-fluid-2__grid-template-rows","100%"),root.style.setProperty("--pos-banner-fluid-2__decor-grid-column","2"),root.style.setProperty("--pos-banner-fluid-2__decor-grid-row","1"),root.style.setProperty("--pos-banner-fluid-2__decor-padding","30px 30px 30px 0"),root.style.setProperty("--pos-banner-fluid-2__content-padding","30px"),root.style.setProperty("--pos-banner-fluid-2__bg-url","url('https://pos.gosuslugi.ru/bin/banner-fluid/2/banner-fluid-bg-2.svg')"),root.style.setProperty("--pos-banner-fluid-2__bg-position","0% center"),root.style.setProperty("--pos-banner-fluid-2__bg-size","cover"),root.style.setProperty("--pos-banner-fluid-2__slogan-font-size","24px"),root.style.setProperty("--pos-banner-fluid-2__slogan-line-height","32px"),root.style.setProperty("--pos-banner-fluid-2__logo-wrap-padding","30px 30px 24px 40px"),root.style.setProperty("--pos-banner-fluid-2__logo-wrap-top","initial"),root.style.setProperty("--pos-banner-fluid-2__logo-wrap-bottom","0"),root.style.setProperty("--pos-banner-fluid-2__logo-wrap-border-radius","80px 0 0 0"))}displayWindowSize();var resizeListener=window.addEventListener("resize",displayWindowSize);window.onunload=function(){window.removeEventListener("resize",resizeListener)};
</script>
 <script>Widget("https://pos.gosuslugi.ru/form", 219732)</script>  

                                                        <!-- ВИДЖЕТ -->

                    </div>

                    <div class="services__items">

                        <div class="services__item">

                            <a class="services__item-link" href="<?php echo get_page_link(442); ?> "></a>

                            <h4 class="services__item-title"><?php the_field('services__item-title-1', 2) ?></h4>

                            <p class="services__item-text"><?php the_field('services__item-text-1', 2) ?></p>

                        </div>

                        <div class="services__item">

                            <a class="services__item-link" href="<?php echo get_page_link(444); ?> "></a>

                            <h4 class="services__item-title"><?php the_field('services__item-title-2', 2) ?></h4>

                            <p class="services__item-text"><?php the_field('services__item-text-2', 2) ?></p>

                        </div>

                        <div class="services__item">

                            <a class="services__item-link" href="#"></a>

                            <h4 class="services__item-title"><?php the_field('services__item-title-3', 2) ?></h4>

                            <p class="services__item-text"><?php the_field('services__item-text-3', 2) ?></p>

                        </div>

                        <div class="services__item">

                            <a class="services__item-link" href="#"></a>

                            <h4 class="services__item-title"><?php the_field('services__item-title-4', 2) ?></h4>

                        </div>

                        <div class="services__item">

                            <a class="services__item-link" href="#"></a>

                            <h4 class="services__item-title"><?php the_field('services__item-title-5', 2) ?></h4>

                        </div>

                        <div class="services__item">

                            <a class="services__item-link" href="#"></a>

                            <h4 class="services__item-title"><?php the_field('services__item-title-6', 2) ?></h4>

                        </div>

                        <div class="services__item">

                            <a class="services__item-link" href="<?php echo get_page_link(443); ?> "></a>

                            <h4 class="services__item-title"><?php the_field('services__item-title-7', 2) ?></h4>

                            <p class="services__item-text"><?php the_field('services__item-text-7', 2) ?></p>

                        </div>

                        <div class="services__item">

                            <a class="services__item-link" href="#"></a>

                            <h4 class="services__item-title"><?php the_field('services__item-title-8', 2) ?></h4>

                        </div>

                        <div class="services__item">

                            <a class="services__item-link" href="<?php echo get_page_link(476); ?> "></a>

                            <h4 class="services__item-title"><?php the_field('services__item-title-9', 2) ?></h4>

                            <p class="services__item-text"><?php the_field('services__item-text-9', 2) ?></p>

                        </div>

                        <div class="services__item">

                            <a class="services__item-link" href="#"></a>

                            <h4 class="services__item-title"><?php the_field('services__item-title-10', 2) ?></h4>

                        </div>

                        <div class="services__item">

                            <a class="services__item-link" href="#"></a>

                            <h4 class="services__item-title"><?php the_field('services__item-title-11', 2) ?></h4>

                        </div>

                        <div class="services__item">

                            <a class="services__item-link" href="<?php echo get_page_link(492); ?> "></a>

                            <h4 class="services__item-title main"><?php the_field('services__item-title-12', 2) ?></h4>

                            <h4 class="services__item-title"><?php the_field('services__item-text-12', 2) ?></h4>

                        </div>

                    </div>

                    <span class="da"></span>

                    <div class="services__news">

                        <div class="services__news-items">

                            <div class="services__news-item">

                                <div class="services__news-item--img-wrapper">

                                    <img class="services__news-item--img" src="<?php the_field('services__news-item--img-1', 2) ?>" alt="news">

                                    <p class="services__news-item--img-text"><?php the_field('services__news-item--img-text-1', 2) ?></p>

                                </div>

                                <ul class="services__news-item-lists">

                                <?php
if ( have_posts() ) :
  query_posts('cat=1');
  while (have_posts()) : the_post();
?>
    <li class="services__news-item-list"><?php the_time( 'd.m.y') ?>  
    <a class="inner__link-services" href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
    </li>  

<?php 
  endwhile;
endif;

wp_reset_query();                
?>


                                </ul>

                            </div>

                            <span class="news__border"></span>

                            <div class="services__news-item">

                                <div class="services__news-item--img-wrapper">

                                        <img class="services__news-item--img" src="<?php the_field('services__news-item--img-2', 2) ?>" alt="message">

                                    <p class="services__news-item--img-text-message"><?php the_field('services__news-item--img-text-2', 2) ?></p>

                                </div>

                                <ul class="services__news-item-lists">
                                <?php
if ( have_posts() ) :
  query_posts('cat=2,3');
  while (have_posts()) : the_post();
?>
    <li class="services__news-item-list"><?php the_time( 'd.m.y') ?>  
    <a class="inner__link-services" href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
    </li>  

<?php 
  endwhile;
endif;

wp_reset_query();                
?>

                                </ul>

                            </div>

                        </div>

                        <div class="services__news-item--link">

                            <a class="services__news-item--link-link" href="<?php echo get_category_link(35);?>">Все новости</a>

                        </div>

                    </div>

                    <div class="services__event">
                        <div class="services__event-items">

<?php
global $wp_query;

$wp_query = new WP_Query(array(
    'cat' => '1,2,3,5,33,35,42,43,45',
	'posts_per_page' => '10',
	'paged' => get_query_var('page') ?: 1 // страница пагинации
)); ?>
<?php if ( have_posts() ) :
        while (have_posts()) : the_post();
?>

    <div class="services__event-item">
            <div class="services__event-item-image">
                <?php the_post_thumbnail('mytheme-mini'); ?>
            </div>
   
            <div class="services__event-item--inner">
                <h2 class=".services__event-item--title" style="font-size: 18px; margin: 0 0 5px 0; border: none;">
                    <a class="inner__link" style="border: none; padding: 0;" href="<?php the_permalink(); ?>">
                        <?php the_title(); ?>
                    </a>
                </h2>
                <p style="margin: 10px 0;">
                    <?php the_time( 'd.m.y') ?>
                <p>
                <p class="services__event-item--text" style="margin: 0 0 0 0;">
                    <?php do_excerpt(get_the_excerpt(), 25); ?>
                </p>
            </div> 
    </div>  

<?php 
endwhile; 
endif;?>
<div class="pagi-block">	
            	<?php the_posts_pagination(); ?>
        </div>
<?php
wp_reset_query();                
?>

                        </div>
                    </div>

                    <div class="services__links">

                        <div class="services__links-items">

                            <div class="services__links-item">

                                <a class="services__links-item--link" href="<?php the_field('services__links-1', 2) ?>"></a>

                                <img class="services__links-item--img" src="<?php the_field('services__links-item--img-1', 2) ?>" alt="link">

                            </div>

                            <div class="services__links-item">

                                <a class="services__links-item--link" href="<?php the_field('services__links-2', 2) ?>"></a>

                                <img class="services__links-item--img" src="<?php the_field('services__links-item--img-2', 2) ?>" alt="link">

                            </div>

                            <div class="services__links-item">

                                <a class="services__links-item--link" href="<?php the_field('services__links-3', 2) ?>"></a>

                                <img class="services__links-item--img" src="<?php the_field('services__links-item--img-3', 2) ?>" alt="link">

                            </div>

                            <div class="services__links-item">

                                <a class="services__links-item--link" href="<?php the_field('services__links-4', 2) ?>"></a>

                                <img class="services__links-item--img" src="<?php the_field('services__links-item--img-4', 2) ?>" alt="link">

                            </div>

                            <div class="services__links-item">

                                <a class="services__links-item--link" href="<?php the_field('services__links-5', 2) ?>"></a>

                                <img class="services__links-item--img" src="<?php the_field('services__links-item--img-5', 2) ?>" alt="link">

                            </div>

                            <div class="services__links-item">

                                <a class="services__links-item--link" href="<?php the_field('services__links-6', 2) ?>"></a>

                                <img class="services__links-item--img" src="<?php the_field('services__links-item--img-6', 2) ?>" alt="link">

                            </div>

                            <div class="services__links-item">

                                <a class="services__links-item--link" href="<?php the_field('services__links-7', 2) ?>"></a>

                                <img class="services__links-item--img" src="<?php the_field('services__links-item--img-7', 2) ?>" alt="link">

                            </div>

                            <div class="services__links-item">

                                <a class="services__links-item--link" href="<?php the_field('services__links-8', 2) ?>"></a>

                                <img class="services__links-item--img" src="<?php the_field('services__links-item--img-8', 2) ?>" alt="link">

                            </div>

                            <div class="services__links-item">

                                <a class="services__links-item--link" href="<?php the_field('services__links-9', 2) ?>"></a>

                                <img class="services__links-item--img" src="<?php the_field('services__links-item--img-9', 2) ?>" alt="link">

                            </div>

                            <div class="services__links-item">

                                <a class="services__links-item--link" href="<?php the_field('services__links-10', 2) ?>"></a>

                                <img class="services__links-item--img" src="<?php the_field('services__links-item--img-10', 2) ?>" alt="link">

                            </div>

                            <div class="services__links-item">

                                <a class="services__links-item--link" href="<?php the_field('services__links-11', 2) ?>"></a>

                                <img class="services__links-item--img" src="<?php the_field('services__links-item--img-11', 2) ?>" alt="link">

                            </div>

                            <div class="services__links-item">

                                <a class="services__links-item--link" href="<?php the_field('services__links-12', 2) ?>"></a>

                                <img class="services__links-item--img" src="<?php the_field('services__links-item--img-12', 2) ?>" alt="link">

                            </div>

                        </div>

                    </div>

                </div>

            </section>

        </div>

    </div>

    <?php get_footer(); ?>