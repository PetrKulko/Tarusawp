<!DOCTYPE html>

<html lang="ru">



<head>

    <meta charset="UTF-8">

    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">






    <?php wp_head(); ?>



</head>



<body>

    <header class="header">

        <div class="container">

            <div class="header__top" style="background-image: url(<?php the_field('header__top', 2) ?>);">

                <div class="header__top-wrapper">

                    <div class="header__logo">

                        <a class="header__logo-link" href="<?php echo get_page_link(548); ?>">

                            <img class="logo" src="<?php the_field('logo', 2) ?>" alt="logo">

                        </a>

                        <h1 class="header__top-title"><?php the_field('header__top-title', 2) ?></h1>

                    </div>

                        <img class="header__top-img" src="<?php the_field('header__top-images', 2) ?>" alt="Tarusa">

                </div>

            </div>

            <div class="section">

                <a href="#header" class="menu-btn">

                    <span></span>

                </a>

            </div>



            <nav>

            <?php wp_nav_menu(); ?>

            </nav>

        </div>

    </header>