<form class="services__search" action="#">

<input class="services__search-row" type="text" name="s">

<button class="services__search-btn">

    <img class="services_search-btn--img" src="<?php bloginfo( 'template_url' ); ?>/assets/img/search.png" alt="search">

</button>

</form>