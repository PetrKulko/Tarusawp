<?php get_header(); ?>

<div class="container">
<div class="bg"></div>
<div class="wrapper">
    <div class="sidebar__saerch">
<?php get_sidebar(); ?>
</div>
<section class="services wr-search" style="padding-top: 0">
<div class="breadcrumb">
<a href="<?php echo get_page_link(548); ?>">Главная</a> » 
<?php
if(function_exists('bcn_display'))
{
    bcn_display();
}
?>
</div>

<?php
/*
Template Name: search
*/
?>
<?php get_search_form(); ?>
<div class="services__title-wrapper">
<h1  style="font-size: 22px; line-height: 30px; margin: 0 0 10px 7px">
<?php echo 'Результат поиска: ' . '<span>' . get_search_query() . '</span>'; ?>
</h1>
</div>
<?php
if (have_posts()) :
while (have_posts()) : the_post();
?>
<div class="post" style="background-color: #f3f3f3; padding: 5px; margin: 5px 0;">
<h2><a href="<?php the_permalink() ?>"><?php the_title() ?></a></h2>
<p><?php the_excerpt() ?></p>
</div>
<?php endwhile; ?>
<?php
else :
echo "Извините, по Вашему результату ничего не найдено";
endif;
?>
</section>

</div>
</div>

<?php get_footer(); ?>