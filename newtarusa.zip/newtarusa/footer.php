<footer class="footer">
        <div class="container">
            <div class="footer__items">
                <div class="footer__item">
                    <div class="footer__item-inner">
                        <p class="footer__item-copy"><?php the_field('footer__item-copy', 2) ?></p>
                        <p class="footer__item-copy">Официальный сайт</p>
                        <p class="footer__item-copy"> 
                            <a class="sitemap__link" href="<?php echo get_page_link(833); ?>" target="_blank">
                                Карта сайта
                            </a>
                        </p>
                    </div>
                </div>
                <div class="footer__item">
                    <p class="footer__item-text reset"><p>Адрес:</p>
                    <p>Россия, Калужская область, г. Таруса, ул. Розы Люксембург, д. 18</p>
                </div>
                <div class="footer__item">
                    <p class="footer__item-text">Email:</p>
                    <a class="footer__item-email" href="mailto:<?php the_field('footer__item-email', 2) ?>"><?php the_field('footer__item-email', 2) ?></a>
                </div>
                <div class="footer__item">
                    <p class="footer__item-text">Телефон:</p>
                    <a class="footer__item-phone" href="tel:<?php the_field('footer__item-phone', 2) ?>"><?php the_field('footer__item-phone', 2) ?></a>
                </div>
            </div>
        </div>
    </footer>

    <?php wp_footer(); ?>

</body>

</html>
