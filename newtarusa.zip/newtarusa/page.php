<?php get_header(); ?>

<div class="container">
<div class="bg"></div>
<div class="wrapper wr-zapisi">
<?php get_sidebar(); ?>
<section class="services" style="padding-top: 0">
<div class="breadcrumb">
<a href="<?php echo get_page_link(548); ?>">Главная</a> » 
<?php
if(function_exists('bcn_display'))
{
    bcn_display();
}
?>
</div>
<div class="post">

        <div class="services__title-wrapper">
            <h1 class="services__title single__title">
                 <?php the_title(); ?>
            <h1>
        </div>	


    <?php the_content(); ?>
</div>
</div>

</section>
</div>
</div>

<?php get_footer(); ?>