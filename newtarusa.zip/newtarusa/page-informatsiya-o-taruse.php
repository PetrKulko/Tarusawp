<?php get_header(); ?>

<div class="container">
<div class="bg"></div>
<div class="wrapper wr-zapisi">
<?php get_sidebar(); ?>
<section class="services">

<div class="post">
<div class="breadcrumb">
<a href="<?php echo get_page_link(548); ?>">Главная</a> » 
<?php
if(function_exists('bcn_display'))
{
    bcn_display();
}
?>
</div>
        <div class="services__title-wrapper">
            <h1 class="services__title single__title">
                 <?php the_title(); ?>
            <h1>
        </div>	


    <?php the_content(); ?>
</div>

<div class="category-content">
<?php
if ( have_posts() ) :
  query_posts('cat=45');
  while (have_posts()) : the_post();
?>
        <div class="category-article">

<h2>
    <a class="inner__link"  href="<?php the_permalink(); ?>">
         <?php the_title(); ?>
    </a>
</h2>
<div class="podrobnosti podrobnosti__category">
<span class="post-time">Опубликовано: <?php the_time( 'd.m.y') ?></span>
</div>
<!-- <div class="post-photo">
<?php the_post_thumbnail('mytheme-mini'); ?>
</div> -->

<div class="post-content">
    <?php the_excerpt(); ?>
</div>
</div>
</div> 
    </div>  

<?php 
  endwhile;
endif;

wp_reset_query();                
?>
</div>
</div>

</section>
</div>
</div>

<?php get_footer(); ?>