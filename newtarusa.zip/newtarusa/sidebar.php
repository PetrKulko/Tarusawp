<section  class="information">

<div class="information__items">

    <div class="information__item">

        <div class="information__item-title">

            <h4 class="information__item-title--item item-title"><?php the_field('information__item-title--item', 2) ?></h4>

        </div>
        <div class="important-info-block">
        <?php the_field('important-info-1', 2) ?>
        <?php the_field('important-info-2', 2) ?>
        <?php the_field('important-info-3', 2) ?>
        <!-- <?php
if ( have_posts() ) :
  query_posts('cat=44&posts_per_page=1');
  while (have_posts()) : the_post();
?>
    <li class="services__news-item-list">
        <?php the_time( 'd.m.y') ?>
        <?php the_title(); ?>
    </li>  

<?php 
  endwhile;
endif;

wp_reset_query();                
?> -->

        <span id="dots"></span>

        <div id="more">
        <?php the_field('important-info-4', 2) ?>
        <?php the_field('important-info-5', 2) ?>
        <?php the_field('important-info-6', 2) ?>

        <!-- <?php
if ( have_posts() ) :
  query_posts('cat=44&posts_per_page=3&offset=3');
  while (have_posts()) : the_post();
?>
    <li class="services__news-item-list">
        <?php the_time( 'd.m.y') ?>
        <?php the_title(); ?>

    </li>  

<?php 
  endwhile;
endif;

wp_reset_query();                
?> -->
</div>
        </div>


        <button id="btn" class="information__item-btn" onclick="readMore()">Посмотреть все</button>

    </div>


       
    <div class="information__item information__item-links">

        <div class="information__item-title">

            <h4 class="information__item-title--item item-title"><?php the_field('information__item-title--item-2', 2) ?></h4>

        </div>

        <div class="information__item-link"><?php the_field('important-link-1', 2) ?></div>

        <div class="information__item-link"><?php the_field('important-link-2', 2) ?></div>

        <div class="information__item-link"><?php the_field('important-link-3', 2) ?></div>

        <div class="information__item-link"><?php the_field('important-link-4', 2) ?></div>

    </div>

    <div class="information__item information__item-tarusa">

        <div class="information__item-title">

            <h4 class="information__item-title--item item-title"><?php the_field('information__item-title--item-3', 2) ?></h4>

        </div>

            <img class="information__item-img" src="<?php the_field('information__item-img-logo', 2) ?>" alt="logo">

        <p class="information__item-text"><?php the_field('information__item-text', 2) ?></p>

    </div>

</div>

</section>