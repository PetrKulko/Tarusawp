<?php get_header(); ?>

<div class="container">
<div class="bg"></div>
<div class="wrapper wr-category">
<?php get_sidebar(); ?>
<section class="services"  style="padding-top: 0">
<div class="breadcrumb">
<a href="<?php echo get_page_link(548); ?>">Главная</a> » 
<?php
if(function_exists('bcn_display'))
{
    bcn_display();
}
?>
</div>
<div class="services__title-wrapper">
<h1  style="font-size: 22px; line-height: 30px; margin: 0 0 10px 7px">
    <?php if( is_category() )
	echo get_queried_object()->name; ?>
</h1>
</div>
<?php echo category_description(); ?>
<div class="category-content">
<?php if (have_posts()) {
    while(have_posts()) {
        the_post(); ?>

<div class="services__event-item">
<div class="services__event-item-image">
<?php the_post_thumbnail('mytheme-mini'); ?>
</div>

<div class="services__event-item--inner">
<h2 class=".services__event-item--title" style="font-size: 18px; margin: 0 0 5px 0; border: none;">
<a class="inner__link" style="border: none; padding: 0;" href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
<p style="margin: 10px 0;"><?php the_time( 'd.m.y') ?> <p>
<p class="services__event-item--text" style="margin: 0 0 0 0;">
<?php do_excerpt(get_the_excerpt(), 25); ?>
</p>
</div> 
</div>  
<?php 
}
} 
?>
</div>

</section>

</div>
</div>

<?php get_footer(); ?>