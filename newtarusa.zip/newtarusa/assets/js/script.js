function testWebP(callback) {

    var webP = new Image();
    webP.onload = webP.onerror = function () {
    callback(webP.height == 2);
    };
    webP.src = "data:image/webp;base64,UklGRjoAAABXRUJQVlA4IC4AAACyAgCdASoCAAIALmk0mk0iIiIiIgBoSygABc6WWgAA/veff/0PP8bA//LwYAAA";
    }
    
    testWebP(function (support) {
    
    if (support == true) {
    document.querySelector('body').classList.add('webp');
    }else{
    document.querySelector('body').classList.add('no-webp');
    }

    });

// === BURGERMENU === //

    $('.menu-btn').on('click', function(e) {
        e.preventDefault;
        $(this).toggleClass('menu-btn_active');
        $('.menu-menu-container').toggleClass('menu-menu-container-active');
});

// === /BURGERMENU === //

// === READMORE === //


function readMore() {
    let dots = document.getElementById("dots"); 
    let more = document.getElementById("more"); 
    let btn = document.getElementById("btn"); 

    if(dots.style.display === "none") {
        dots.style.display="inline";
        btn.innerHTML="Посмотреть всё";
        more.style.display="none";
    } else {
        dots.style.display="none";
        btn.innerHTML="Скрыть";
        more.style.display="inline";
    }
}

// === /READMORE === //

// === POPUP === //

let html = document.documentElement;
let body = document.querySelector('body');
let popup = document.querySelector('.popup__body');
let bcg = document.querySelector('.services__popup-inner');
let btn = document.querySelector('#write');
let cls = document.querySelector('.pop__close');
let send = document.querySelector('#send__form');

btn.addEventListener('click', popUpStart);
function popUpStart(e) {
    body.classList.add('lock');
    bcg.classList.add('bcg__active');
    popup.classList.add('popup__active');
    let scrollPos = document.body.scrollTop || html.scrollTop;
    popup.style.top = scrollPos + 'px';
}
bcg.addEventListener('click', popUpClose);
send.addEventListener('click', popUpClose);
cls.addEventListener('click', popUpClose);
function popUpClose(params) {
    body.classList.remove('lock');
    bcg.classList.remove('bcg__active');
    popup.classList.remove('popup__active');
}

// === /POPUP === //