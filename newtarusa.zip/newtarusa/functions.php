<?php

// add_filter( 'wpseo_canonical', 'at_remove_dup_canonical_link' );

// function at_remove_dup_canonical_link() {
//     return false;
//     }

    remove_action('wp_head', 'wp_resource_hints', 2);

    remove_action('wp_head', 'rel_canonical');
    

add_action( 'wp_enqueue_scripts', 'newtarusa_style' );
add_action( 'wp_enqueue_scripts', 'newtarusa_scripts' ); 
add_action( 'after_setup_theme', 'theme_register_nav_menu' );
function theme_register_nav_menu() {
    register_nav_menu( 'Верхнее', 'Главное меню' );
	add_theme_support( 'post-thumbnails', array( 'post' ) );
	add_image_size( 'newtarusa', 1024, 9999, false );
}




function newtarusa_style() {
	wp_enqueue_style( 'main-style', get_stylesheet_uri() );
	wp_enqueue_style('header', get_template_directory_uri() . '/assets/css/header.css');
	wp_enqueue_style('zapisi', get_template_directory_uri() . '/assets/css/zapisi.css');
	wp_enqueue_style('blockquote', get_template_directory_uri() . '/assets/css/blockquote.css');
    wp_enqueue_style('pagination', get_template_directory_uri() . '/assets/css/pagination.css');
    wp_enqueue_style('404', get_template_directory_uri() . '/assets/css/404.css');
    wp_enqueue_style('contacts', get_template_directory_uri() . '/assets/css/contacts.css');
}

function newtarusa_scripts() {

    wp_enqueue_script( 'dynamic-script', get_template_directory_uri() . '/assets/js/jquery.js', array(), null, true );
	wp_enqueue_script( 'dynamic-script', get_template_directory_uri() . '/assets/js/dynamicAdapt.js', array(), null, true );
    wp_enqueue_script( 'script-script', get_template_directory_uri() . '/assets/js/script.js', array(), null, true );
}
add_filter( 'excerpt_length', function(){
	return 60;
} );
add_filter('excerpt_more', function($more) {
	return '...';
});

function do_excerpt($string, $word_limit) {
    $words = explode(' ', $string, ($word_limit + 1));
    if (count($words) > $word_limit)
    array_pop($words);
    echo implode(' ', $words).'';
  }

// ПРОСМОТРЫ
function getPostViews($postID){
    $count_key = 'post_views_count';
    $count = get_post_meta($postID, $count_key, true);
    if($count==''){
        delete_post_meta($postID, $count_key);
        add_post_meta($postID, $count_key, '0');
        return "0";
    }
    return $count;
}
function setPostViews($postID) {
    $count_key = 'post_views_count';
    $count = get_post_meta($postID, $count_key, true);
    if($count==''){
        $count = 0;
        delete_post_meta($postID, $count_key);
        add_post_meta($postID, $count_key, '0');
    }else{
        $count++;
        update_post_meta($postID, $count_key, $count);
    }
}


add_action('init', 'disable_emojis');

function disable_emojis(){

 remove_action('wp_head', 'print_emoji_detection_script', 7);
    remove_action('admin_print_scripts', 'print_emoji_detection_script');
   remove_action('wp_print_styles', 'print_emoji_styles');
 remove_action('admin_print_styles', 'print_emoji_styles');
  remove_filter('the_content_feed', 'wp_staticize_emoji');
    remove_filter('comment_text_rss', 'wp_staticize_emoji');
    remove_filter('wp_mail', 'wp_staticize_emoji_for_email');

   add_filter('tiny_mce_plugins', 'tiny_mce_plugins_disable_emojis');

  return false;
}

function tiny_mce_plugins_disable_emojis($plugins){

   if(is_array($plugins)){

     return array_diff($plugins, array('wpemoji'));
    }

   return array();
}


// remove_action('wp_head', 'wlwmanifest_link');

// remove_action('wp_head', 'rel_canonical');

// remove_action('wp_head', 'wp_shortlink_wp_head', 10, 0);
// remove_action('template_redirect', 'wp_shortlink_header', 11, 0);

// remove_action('wp_head', 'wp_generator');
// add_filter('the_generator', '__return_empty_string');


// function wpschool_remove_yoast_jsonld( $data ){
//     $data = array();
//     return $data;
// }
// add_filter( 'wpseo_json_ld_output', 'wpschool_remove_yoast_jsonld', 10, 1 );


// function hentry_class_remover( $classes ) {
//     $classes = array_diff( $classes, array( 'hentry' ) );
//     return $classes;
//   }
//   add_filter( 'post_class', 'hentry_class_remover' );

//   add_filter( 'wpseo_json_ld_output', '__return_empty_array' );



require_once( dirname(__FILE__) . '/class-Kama_SEO_Tags.php');
require_once( dirname(__FILE__) . '/Kama_Post_Meta_Box.php');
Kama_SEO_Tags::init();

class_exists('Kama_Post_Meta_Box') && new Kama_Post_Meta_Box( array(
	'id'     => '_seo',
	'title'  => 'SEO поля',
	'fields' => array(
		'title' => array(
			'type'=>'text',    'title'=>'Title',       'desc'=>'Заголовок страницы (рекомендуется 70 символов)', 'attr'=>'style="width:99%;"'
		),
		'description' => array(
			'type'=>'textarea','title'=>'Description', 'desc'=>'Описание страницы (рекомендуется 160 символов)', 'attr'=>'style="width:99%;"'
		),
		'keywords' => array(
			'type'=>'text',    'title'=>'Keywords',    'desc'=>'Ключевые слова для записи',       'attr'=>'style="width:99%;"'
		),
		'robots' => array(
			'type'=>'radio',   'title'=>'Robots',      'options' => array(''=>'index,follow', 'noindex,nofollow'=>'noindex,nofollow')
		),
	),
) );


